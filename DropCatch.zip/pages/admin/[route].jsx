import MyLayout from "../../Components/Layout";

export default function AdminRoute() {
  return <MyLayout />;
}
