import { Image } from "@nextui-org/react";

const dynadot = "/img/icons/dynadot.jpeg";
export default function Dynadot() {
  return (
    <>
      <Image src={dynadot} height={25} />
    </>
  );
}
