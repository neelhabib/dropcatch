import { Image } from "@nextui-org/react";

const namesilo = "/img/icons/namesilo.jpeg";
export default function NameSilo() {
  return (
    <>
      <Image src={namesilo} height={25} />
    </>
  );
}
