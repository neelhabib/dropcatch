export default function Admin() {
  return null;
}
